import React from 'react'
import Details from '../components/Details';

const Contact = () => {
  return (
    <Details />
  )
}

export default Contact