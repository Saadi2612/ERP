const reviews = [
    {
      id: 1,
      name: 'Jeniffer Smith',
      job: 'CHEF',
      image:
        'https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883334/person-1_rfzshl.jpg',
      text:
        "Our business has seen a significant increase in efficiency since implementing ERP Solution. It has streamlined our processes and allowed us to make better use of our resources.",
    },
    {
      id: 2,
      name: 'Pamela Duncan',
      job: 'Director',
      image:
        'https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883409/person-2_np9x5l.jpg',
      text:
        'The support team is always available to help and the solution has been very reliable. We have seen a noticeable improvement in our business since using Construction ERP.',
    },
    {
      id: 3,
      name: 'Steve Tailor',
      job: 'CFO',
      image:
        'https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883417/person-3_ipa0mj.jpg',
      text:
        'The Construction ERP has made it easier for us to manage our finances and budgeting. We have been able to reduce costs and increase profitability as a result.',
    },
  ];
  
  export default reviews;