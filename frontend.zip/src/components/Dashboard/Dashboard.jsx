import React, { useState, useEffect } from "react";
import ProjectFormButton from "./ProjectForm";
import ProjectSummary from "./ProjectSummary";
import MilestoneProgress from "./MilestoneProgress";
import InventoryTable from "../Services/InventoryTable";
import axios from "axios";
import {
  Container,
  Grid,
  Button,
  makeStyles,
  createStyles,
} from "@material-ui/core";

const useStyles = makeStyles((theme) =>
  createStyles({
    root: {
      display: "flex",
      minHeight: "100vh",
      padding: 0,
    },
    sidebar: {
      backgroundColor: "#333",
      textAlign: "center",
      margin: "0 auto",
      color: "#fff",
      padding: theme.spacing(2),
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      width: 300,
    },
    addButton: {
      marginBottom: theme.spacing(2),
      backgroundColor: "#2196f3",
      color: "#fff",
      "&:hover": {
        backgroundColor: "#1976d2",
      },
    },
    link: {
      color: "#fff",
      marginBottom: theme.spacing(1),
      textDecoration: "none",
      "&:hover": {
        textDecoration: "underline",
      },
    },
    content: {
      padding: theme.spacing(2),
    },
  })
);

const Dashboard = () => {
  const classes = useStyles();
  const [showForm, setShowForm] = useState(false);
  const [projects, setProjects] = useState([]);
  const [milestones, setMilestones] = useState([]);

  const handleFormSubmit = (project, milestone) => {
    console.log(project, "HEHEH");
    setProjects([...projects, project]);
    setMilestones([...milestones, milestone]);
    setShowForm(false);
  };

  const [showInventory, setShowInventory] = useState(false);

  const toggleShowInventory = () => {
    setShowInventory(!showInventory);
  }

  const [showProjectForm, setShowProjectForm] = useState(false);

  const toggleShowProjectForm = () => {
    setShowProjectForm(!showProjectForm);
  };


  const [inventoryArray, setInventoryArray] = useState([]);

  const fetchRecords = async () => {
    try {
      const response = await axios.get("http://localhost:5000/dashboard");
      //setRecords(response.data);
      //console.log(response.data);
      setInventoryArray(response.data.inventoryData);
    } catch (error) {
      console.error("Failed to fetch records:", error);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);


  return (
    <div className={classes.root}>
      <Grid container spacing={2}>
        <Grid item xs={12} md={3} className={classes.sidebar}>
          <div className={classes.sidebar}>
            <ProjectFormButton onSubmit={handleFormSubmit} />

            <Button variant="contained" onClick={toggleShowInventory}>
              {showInventory ? "Hide Inventory" : "Show Inventory"}
            </Button>

            <Button variant="contained" onClick={toggleShowProjectForm}>
              {showProjectForm ? "Hide Project Form" : "Show Project Form"}
            </Button>
            
          </div>
        </Grid>
        <Grid item xs={12} md={9} className={classes.content}>
          <div className={classes.content}>
            <ProjectSummary projects={projects} />
            {/* <MilestoneProgress milestones={milestones} /> */}

            {showInventory ? (
              <div>
                <InventoryTable inventoryArray={inventoryArray} />
                <button className="refresh-btn" onClick={fetchRecords}>
                  Refresh Inventory
                </button>
              </div>
            ) : null}
          </div>
        </Grid>
      </Grid>
    </div>
  );
};

export default Dashboard;
